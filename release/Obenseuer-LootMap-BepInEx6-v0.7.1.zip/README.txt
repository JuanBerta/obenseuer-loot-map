﻿Obenseuer Loot Map 0.7.1 (BepInEx 6)
====================================

Marks containers, pickup spots, workstations, shops and recipes/blueprints on the game's map page, and lets you search for any item.

Install
-------
Extract the archive into your Obenseuer folder (the one with Obenseuer.exe), so the files end up in
  BepInEx\plugins\LootMap\
Needs BepInEx 6 (be.697 or newer). Replace the old files when updating.

Use
---
Open the map page. The Loot Map panel sits beside it (F6 shows or hides it; change TogglePanelKey in the config if F6 clashes with another mod).
- Type an item, container, workstation, recipe or blueprint name to filter the markers. Click a marker to be guided there.
- Purple round markers are recipes and blueprints; hollow ones are empty or waiting to respawn.
- Switches in the panel: containers, pickup spots, recipes & blueprints, workstations, shops, doors, only free to take, only my floor, search other buildings.
- More tools (panel): find by value or effect, hide emptied containers, paste a shopping list from the website, plan a route.
- Doors: padlock = locked (lockpick or key), crossed padlock = blocked, plain = open.

