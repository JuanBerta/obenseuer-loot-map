Obenseuer Loot Map 0.8.0 (BepInEx 6, Unity Mono)

An in-game version of the Loot Map: markers for containers, pickup spots, workstations and shops, search, "guide me there", a Profit finder, a Craft planner and a shopping list.

Install:
1. Install BepInEx 6 (Unity Mono) in the Obenseuer folder.
2. Extract this archive into the Obenseuer folder (keep BepInEx/plugins/LootMap/ together with lootmap-data.json).
3. Start the game. F6 shows or hides the panel on the Map tab; Home opens the big window anywhere in the game.

Settings are in BepInEx/config/com.juanberta.obenseuer.lootmap.cfg.
Website with the same data: https://juanberta.github.io/obenseuer-loot-map/
